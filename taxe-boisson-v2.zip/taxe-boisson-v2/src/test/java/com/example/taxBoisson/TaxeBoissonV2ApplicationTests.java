package com.example.taxBoisson;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaxeBoissonV2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
