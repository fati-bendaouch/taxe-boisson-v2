package com.example.taxBoisson;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TaxeBoissonV2Application {

	public static void main(String[] args) {
		SpringApplication.run(TaxeBoissonV2Application.class, args);
	}

}
